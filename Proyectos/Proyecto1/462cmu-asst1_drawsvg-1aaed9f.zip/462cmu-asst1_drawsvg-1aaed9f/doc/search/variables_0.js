var searchData=
[
  ['a',['a',['../class_c_m_u462_1_1_color.html#af4499c6f417283b77c3fa38697df65c0',1,'CMU462::Color']]]
];
