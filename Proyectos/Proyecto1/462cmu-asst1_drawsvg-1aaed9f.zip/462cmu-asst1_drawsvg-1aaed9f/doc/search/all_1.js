var searchData=
[
  ['b',['b',['../class_c_m_u462_1_1_color.html#a5ae56ddf662d80a6cfd423664d99d648',1,'CMU462::Color']]]
];
