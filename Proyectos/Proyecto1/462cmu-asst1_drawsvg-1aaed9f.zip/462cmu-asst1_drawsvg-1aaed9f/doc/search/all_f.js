var searchData=
[
  ['unit',['unit',['../class_c_m_u462_1_1_vector2_d.html#aecad9e083d41f03929fb01e60851dfa8',1,'CMU462::Vector2D::unit()'],['../class_c_m_u462_1_1_vector3_d.html#ade58b0e3fdaa28e083595f1350c71c7f',1,'CMU462::Vector3D::unit()']]]
];
