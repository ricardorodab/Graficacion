var searchData=
[
  ['g',['g',['../class_c_m_u462_1_1_color.html#a4a3179778bc75342961e5b96a1b8b228',1,'CMU462::Color']]]
];
