#include <iostream>

using namespace std;
	
	//Metodo para calcular la longitud de unac-string, la cadena debe de terminar con el caracter especial /0
	int StringLength(char* str){
		int cnt = 0;
		while( str[cnt] != '\0' )
			++cnt; //Contador.
		// Regresa el numero de caracteres.
		return cnt;
	}


	int main(){

		char str[6] = {'H', 'e', 'l', 'l', 'o', '\0'};//Una c-string
		cout << "str = ";

		//Podemos imprimir en pantalla caracter por caracter
		for(int i = 0; i < StringLength(str); ++i)
			cout << str[i];
		cout << endl;

		//o bien usamos cout, pues ya tiene implementado la anterior
		cout << "str = ";
		cout << str;
		cout << endl;
		
		//Calculamos la longitud de la cadena
		cout << "str Length= ";
		cout << StringLength(str);
		cout << endl;
		
	}

