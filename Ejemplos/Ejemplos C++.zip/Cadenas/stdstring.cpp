#include <iostream>
#include <string> //Para incluir a las std::string

using namespace std;

	int main(){
		
		string s = "Hello, world!";
		
		//Metodo length y size
		int length = s.length();
		int size = s.size();
		cout << "length = " << length << endl;
		cout << "size = " << size << endl;
		
		//Operadores
		string s0 = "Hello";
		string s1 = "Hello";
		string s2 = "abc";
		string s3 = "abcd";
                cout << (s0 == s1) << endl;		
                cout << (s0 != s1) << endl;
                cout << (s1 == s2) << endl;
                cout << (s2 < s3) << endl;
                cout << (s3 > s2) << endl;

		//Concatenacion
		string A = "Hello, ";
		string B = "world!";
		string C = A + B; // suma = "Hello, world!"
		cout << C << endl;

		//Cadena vacia
		string emptyString = "";
		string notEmptyStr = "abcdef";
		if( emptyString.empty() == true )
			cout << "emptyString is empty." << endl;
		else
			cout << "emptyString is actually not empty." << endl;
		if( notEmptyStr.empty() == true )
			cout << "notEmptyStr is empty." << endl;
		else
			cout << "notEmptyStr is actually not empty." << endl;
		
		//Pasar de c-string a std::string
		string st1 = "Assignment";
		string t("Constructor");

		//Pasar de std::string a c-string
                string st2 = "Assignment";
		const char* cstring = s2.c_str(); // cstring = "Assignment"


		//getline 2
		string str2 = "";
		cout << "Enter a multiple word string: ";
		getline(cin, str2); //cin es el flujo de entrada, pero solo nos permite obtener la cadena hasta un espacio
				    //getline nos permite obtener la cadena completa incluyendo espacios
		cout << "You entered: " << str2 << endl;

	}

