#include <iostream>
#include <string>
#include "person.h"

using namespace std;

	int main(){

		Person mike("Mike", 32);
		cout << "Name =" << mike.getName() <<endl;
		Person tim("Tim",34);
		cout << "Age =" << tim.getAge() << endl;
		Person vanessa("Vanessa", 26);
		vanessa.talk(tim);

	}

