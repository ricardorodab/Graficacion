// Class definition
#include <iostream>
#include <string>

class Person
{

public:

	Person(std::string name, int age);
	std::string getName();
	int getAge();
  	void talk(Person& p);

private:
	std::string name;
	int age;
};

