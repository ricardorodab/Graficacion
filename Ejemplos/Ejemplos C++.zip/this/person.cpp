#include <iostream>
#include <string>
#include "person.h"

using namespace std;

	Person::Person(string name, int age){
		this->name = name;//Operador this
		this->age = age;
	}
	
	string Person::getName(){
		return this->name;
	}
	
	int Person::getAge()
	{
		return this->age;
	}

	void Person::talk(Person& p)
	{
		cout << this->name << " is talking to ";
		cout << p.name << endl;
	}


