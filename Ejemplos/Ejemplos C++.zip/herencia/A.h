
class A
{
public:
A();
};

class B : public A
{
public:
B();
};
