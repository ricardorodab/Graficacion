#include <stdio.h>
#include "F.h"


A::A(int something)
{
printf("Something = %d\n", something);
}

B::B(int something) : A(something)
{
}


