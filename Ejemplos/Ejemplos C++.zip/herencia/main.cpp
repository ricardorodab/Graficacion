#include <stdio.h>
#include <iostream>
#include "F.h"

using namespace std;

int main(){

	//A a(12);
	B b(144);
	b.abstractMethod();
}
