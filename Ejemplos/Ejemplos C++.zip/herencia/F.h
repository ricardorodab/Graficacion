//Clase base
class A
{
public:
A(int something);
virtual ~A();
virtual void F();//estas funciones se púeden sobre escribir en las subclases
virtual void abstractMethod() = 0; 
};

//Subclase
class B : public A
{
public:
B(int something);
virtual ~B();
virtual void F();
virtual void abstractMethod(); 
};
