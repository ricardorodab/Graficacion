#include <iostream>
#include <string>

using namespace std;

//Ejemplos de estructuras

//struct identificador_de_la estructura {
//miembros_de_la_estructura
//}objeto_de_la_estructura
struct Person {
   string Name;
   string Address; 
   int year; 
};

struct Point { 
   int x, y; 
   //Una estructura puede incluir mas que solo variables
   Point(); // Declaración del constructor
} Point1, Point2;
 
// Definición del constructor, fuera de la estructura
Point::Point() {  
   x = 0; 
   y = 0; 
}

struct stPar { 
   int A, B; 
   //Los metodos en la estructuras, si son implementados debe ser cortos
   int getA() { return A;} // Devuelve el valor de A
   int getB() { return B;} // Devuelve el valor de B
   void setA(int n) { A = n;} // Asigna un nuevo valor a A
   void setB(int n) { B = n;} // Asigna un nuevo valor a B
}Par;


struct A {
   int i;
   int j;
   int k;
};

//Ejemplo de una estructura anidada
struct B {
   int x;
   //Estructura anidada
   struct C {
      char c;
      char d;
   } y;
   int z;
};

 
int main() { 

   Person fer;//si no fue declara en los objetos de la estructura
   fer.Name = "Fer";//Accedemos a sus miembros o metodos con el operador punto como en u objeto
   cout << fer.Name << endl;

   Par.setA(15); 
   Par.setB(63); 
   cout << Par.getA() << endl; 
   cout << Par.getB() << endl;
	
   //Inicializacion de estructuras
   A a = {10, 20, 30};//estructuras no anidada
   B b = {10, {'a', 'b'}, 20};//estructuras anidada (int x, struct C(c,d), z)
             
   Point1.x = 10; 
   Point1.y = 12; 
   Point2 = Point1; //Este es lo mismo que hacer Point.y = Point.y y Point.x = Point.x

}
