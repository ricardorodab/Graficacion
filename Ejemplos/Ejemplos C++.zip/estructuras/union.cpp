#include <iostream>
using namespace std;
 
//Ejemplos de uniones 


union unEjemplo { 
   int A; 
   char B; 
   double C; 
} UnionEjemplo;



struct stCoor3D { 
   int X, Y, Z; 
};

//sin estructuras anonimas
union unCoor3D1 { 
   stCoor3D N;
   int Coor[3]; 
} Punto1;

//con estructuras anonimas
union unCoor3D2 { 
   struct { 
      int X, Y, Z; 
   }; 
   int Coor[3]; 
} Punto2;

struct tipoLibro {
    int codigo;
    char autor[80];
    char titulo[80];
    char editorial[32];
    int anno;
};

struct tipoRevista {
    int codigo;
    char nombre[32];
    int mes;
    int anno;
};

struct tipoPelicula {
    int codigo;
    char titulo[80];
    char director[80];
    char productora[32];
    int anno;
};

//sin descriminante
union tipoEjemplar1 {
    tipoLibro l;
    tipoRevista r;
    tipoPelicula p;
};

//con descriminante
enum eEjemplar { libro, revista, pelicula };//usamos enumeraciones pero puedeser cualquier 
					    //identificador que nos permita saber de que tipo 
					    //de estructura se trata

struct tipoEjemplar2 {
    eEjemplar tipo;
    union {
        tipoLibro l;
        tipoRevista r;
        tipoPelicula p;
    };
};

int main() { 

   UnionEjemplo.A = 100; 
   cout << UnionEjemplo.A << endl; 
   UnionEjemplo.B = 'a'; 
   cout << UnionEjemplo.B << endl; 
   UnionEjemplo.C = 10.32; 
   cout << UnionEjemplo.C << endl; 

   cout << sizeof(unEjemplo) << endl; 
   cout << sizeof(UnionEjemplo.A) << endl; 
   cout << sizeof(UnionEjemplo.B) << endl; 
   cout << sizeof(UnionEjemplo.C) << endl; 

   cout << "Punto.N.X =" << Punto1.N.X << endl;//sin estruturas anidas debemos acceder de la manera Punto.N.X 
   cout << "Punto.X =" << Punto2.X << endl;//con estruturas anidas podemos acceder de la manera Punto.X 


}
