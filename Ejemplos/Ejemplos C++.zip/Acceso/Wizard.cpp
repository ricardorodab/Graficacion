#include "wiz.h"//<- 

using namespace std;


	//Implementacion de los constructores y metodos de wiz.h	
	
	//Constructor de "wizard" con los valores por default 
	//Nombre_de_la_clase::Nombre_del_constructor(Lista de parametros)
	Wizard::Wizard(){	
		mName = "DefaultName";
		mHitPoints = 0;
		mMagicPoints = 0;
		mArmor = 0;
	}

        /*
	//Lista de parametros
	Wizard::Wizard() : mName("DefaultName"),  mHitPoints(0), mMagicPoints(0), mArmor(0)
	{	

	}
        */   

	//Constructor de "wizard" con los valores especificos.
	Wizard::Wizard(std::string name, int hp, int mp, int armor){
		mName = name;
		mHitPoints = hp;
		mMagicPoints = mp;
		mArmor= armor;
	}

	Wizard::~Wizard(){
	// No hay manejo dinamico de memoria
	}

	//tipo_de_regreso Nombre_de_la_clase::Nombre_del_constructor(Lista de parametros)
	void Wizard::setArmor(int armor){
		if( armor >= 0 )
			mArmor = armor;
	}

	std::string Wizard::getName()
	{
		return mName;
	}
	
	void Wizard::fight(){
		cout << "Fighting." << endl;
	}
	
	void Wizard::talk(){
		cout << "Talking." << endl;
	}

	void Wizard::castSpell(){
		if( mMagicPoints > 4)
			cout << "Casting Spell." << endl;
		else
			cout << "Not enough magic points!" << endl;
	}



