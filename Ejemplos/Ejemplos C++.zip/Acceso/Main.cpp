#include <iostream>
#include <string>
#include "wiz.h" //<-- Para poder declarar objetos Wizard

using namespace std;
	
	int main(){

		//En C++ no usamos new para crear una instancia de la clase
		Wizard wiz0;//Constructor por omision
		Wizard wiz1("Gandalf", 20, 100, 5);//Constructor con valores dados

		wiz0.fight();
		wiz0.talk();

		wiz0.setArmor(10);//Para poder asignarle valor a mArmor
		cout << "Player's name = " << wiz0.getName() << endl;//Para poder obtener mName
		wiz0.castSpell();
		
	}

