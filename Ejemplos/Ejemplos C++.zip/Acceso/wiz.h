
#include <iostream>
#include <string>
class Wizard
{

public:
//inicio public
	//Constructores
	Wizard();
	
	Wizard(std::string name, int hp, int mp, int armor);
	
	// Destructor, solo se utiliza en caso de usar memoria dinamica
	~Wizard();

	// Metodos
	void fight();
	void talk();
	void castSpell();
        void setArmor(int s);//Metodo para poder asignarle valor a mArmor
	std::string getName();//metodo para poder obtener el mName
//fin public

private:
//----- inicio private
	//Variables
	std::string mName;
	int mHitPoints;
	int mMagicPoints;
	int mArmor;
//-----fin private
};


