#include <stdio.h>  // incluye las declaraciones para la biblioteca estandar I/O 
                

int main(int argc, char *argv[])  // Funcion Main
                                  // toma como parametros un entero y un arreglo de cadenas
                                  // and returns an int as the exit code
{
printf("Hello world!\n"); 
}
