
#include <iostream>
#include <string>
class Wizard
{

public:

	//Constructores
	Wizard();
	
	Wizard(std::string name, int hp, int mp, int armor);
	
	// Destructor
	~Wizard();

	// Metodos
	void fight();
	void talk();
	void castSpell();

	//Variables
	std::string mName;
	int mHitPoints;
	int mMagicPoints;
	int mArmor;
};


