#include <iostream>
#include <string>
#include "wiz.h" //<-- Para poder declarar objetos Wizard

using namespace std;
	
	int main(){

		//Wizard wiz0;//Constructor por omision
		Wizard wiz0("Gandalf", 20, 100, 5);//Constructor con valores dados

		wiz0.fight();
		wiz0.talk();
		wiz0.mArmor = 10;
		cout << "Player's name = " << wiz0.mName << endl;

		// Prueba si el jugador tiene suficientes MP
		if( wiz0.mMagicPoints > 4 )
		wiz0.castSpell();
		else
			cout << "Not enough magic points!" << endl;
	}

