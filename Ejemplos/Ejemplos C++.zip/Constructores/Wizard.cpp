#include "wiz.h"
using namespace std;
	
	//Constructor de "wizard" con los valores por default 
	Wizard::Wizard(){	
		mName = "DefaultName";
		mHitPoints = 0;
		mMagicPoints = 0;
		mArmor = 0;
	}
	
/*
	//Lista de parametros
	Wizard::Wizard() : mName("DefaultName"),  mHitPoints(0), mMagicPoints(0), mArmor(0)
	{	
	}
*/

	//Constructor de "wizard" con los valores especificos.
	Wizard::Wizard(std::string name, int hp, int mp, int armor){
		mName = name;
		mHitPoints = hp;
		mMagicPoints = mp;
		mArmor= armor;
	}

	Wizard::~Wizard(){
	// No hay manejo dinamico de memoria
	}


	void Wizard::fight(){
		cout << "Fighting." << endl;
	}
	
	void Wizard::talk(){
		cout << "Talking." << endl;
	}

	void Wizard::castSpell(){
		cout << "Casting Spell." << endl;
	}


