#ifndef WIZARD_H
#define WIZARD_H

#include <iostream>
#include <string>
class Wizard
{
public:
	// Metodos
	void fight();
	void talk();
	void castSpell();

	//Variables
	std::string mName;
	int mHitPoints;
	int mMagicPoints;
	int mArmor;
};

#endif // WIZARD_H

