#include "wiz.h"
using namespace std;

	void Wizard::fight(){
		cout << "Fighting." << endl;
	}
	
	void Wizard::talk(){
		cout << "Talking." << endl;
	}

	void Wizard::castSpell(){
		cout << "Casting Spell." << endl;
	}


