#include <iostream>
#include <string>
#include "wiz.h" //<-- Para poder declarar objetos Wizard
using namespace std;
	
	int main(){

		Wizard wiz0; // Declara un variabla wizard
		wiz0.mName = "Oz";
		wiz0.fight();
		wiz0.talk();
		wiz0.mArmor = 10;
		cout << "Player's name = " << wiz0.mName << endl;
		// Prueba si el jugador tiene suficientes MP
		if( wiz0.mMagicPoints > 4 )
		wiz0.castSpell();
		else
			cout << "Not enough magic points!" << endl;
}

