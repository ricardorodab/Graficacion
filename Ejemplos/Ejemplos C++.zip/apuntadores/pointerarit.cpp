#include <stdio.h>
 
int main(int argc, char **argv)
{
    int X[6] = { 1, 2, 3, 4, 5, 6 };
    int *prtX;
 
    prtX = X; // incializo el valor del puntero.

    int **r;
    r = &prtX;

    printf("Elemento del arreglo %d\n",X[0]);
    printf("Elemento del arreglo %d\n",X[1]);
    printf("Elemento del arreglo %d\n",X[2]);
    printf("Elemento del arreglo %d\n",X[3]);
    printf("Elemento del arreglo %d\n",X[4]);
    printf("Elemento del arreglo %d\n",X[5]);
    printf("R apunta al entero al que apunta el arreglo %d\n",**r);

    printf("%p\n",prtX);
    prtX += 2;
    printf("R apunta al entero al que apunta el arreglo %d\n",**r);

    printf("%p\n",prtX);	
    prtX -= 2;
    printf("R apunta al entero al que apunta el arreglo %d\n",**r);

    printf("%p\n",prtX);	
    prtX++;
    printf("R apunta al entero al que apunta el arreglo %d\n",**r);

    printf("%p\n",prtX);    
    printf("R apunta al entero al que apunta el arreglo %d\n",**r);

    printf("Elemento del arreglo %d\n",X[0]);
    printf("Elemento del arreglo %d\n",X[1]);
    printf("Elemento del arreglo %d\n",X[2]);
    printf("Elemento del arreglo %d\n",X[3]);
    printf("Elemento del arreglo %d\n",X[4]);
    printf("Elemento del arreglo %d\n",X[5]);

}
