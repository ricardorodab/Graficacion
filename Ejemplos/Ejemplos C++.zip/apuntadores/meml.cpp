#include <iostream>

using namespace std;

       //Ejemplo de fuga de memoria
	void MemLeaker()
	{
	float* arrayOfFloats = new float[100];
	cout << "MemLeaker() called!" << endl;
	//Evita fuga de memoria
	//delete[] arrayOfFloats;
	//arrayOfFloats = 0;
	}
	
	int main()
	{

	for(int i = 0; i < 5; ++i)
		MemLeaker();
	}


