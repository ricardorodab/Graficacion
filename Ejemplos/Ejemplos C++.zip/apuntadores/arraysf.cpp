#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

        //Funcion para imprimir un arreglo
	void PrintArray(int array[20])
	{
        //Imprime el tamaño, en bytes, del parametro;
	cout << "sizeof(array) = " << sizeof(array) << endl;
	//Imprime el arreglo
	for(int i = 0; i < 20; ++i)
	cout << array[i] << " ";
	cout << endl;
	}

	int main(){
	
	// Generador de numeros aleatorios 
	srand( time(0) );

	//Arreglo de 20 enteros
	int randomArray[20];

	//A cada elemento del arreglo se le asigna un numero aleatorio
	for(int i = 0; i < 20; ++i)
		randomArray[i] = rand() % 101;

	//Imprime al tamaño, en bytes, del arreglo
	cout << "sizeof(randomArray) = " << sizeof(randomArray) << endl;
	PrintArray( randomArray );
	return 0;
}

