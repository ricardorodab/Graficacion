
#include <iostream>
#include <string>
#include <sstream>

using namespace std;


//Ejemplo de apuntadores a objetos con miembros

struct movies_t {
  string title;
  int year;
};

int main ()
{

  string mystr;
  movies_t amovie;
  //Apuntador a la estructura 	
  movies_t * pmovie;
  pmovie = &amovie;

  cout << "Enter title: ";
  //Para obtener un miembro de la estructura a la que apunta pmovie, usamos el operador flecha (->)
  //en lugar del operador punto
  getline (cin, pmovie->title);
  cout << "Enter year: ";
  getline (cin, mystr);
  (stringstream) mystr >> pmovie->year;

  cout << "\nYou have entered:\n";
  cout << pmovie->title;
  cout << " (" << pmovie->year << ")\n";

}
