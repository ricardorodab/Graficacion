#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

	// Funcion que "regresa" mas de un parametro usando referencias

	void GetMousePos(int& outX, int& outY){
	// Pretendemos que regresamos la posicion actual del mouse
	outX = rand() % 801;
	outY = rand() % 601;
	}
	
	int main(){

	// Generador de numeros aleatorios
	srand( time(0) );

	// Inicializacion de los dos variables	
	int x = 0;
	int y = 0;

        //Valores de x y y antes del metodo GetMousePos
	cout << "Before GetMousePos(...)" << endl;
	cout << "x = " << x << endl;
	cout << "y = " << y << endl;

	GetMousePos( x, y );

        //Valores de x y y despues del metodo GetMousePos
	cout << "After GetMousePos(...)" << endl;
	cout << "x = " << x << endl;
	cout << "y = " << y << endl;
}

