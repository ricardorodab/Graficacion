#include <stdio.h>

int main(int argc, char **argv) {

int myInteger = 1000;
int *myIntegerPointer1 = &myInteger;

int **myIntegerPointerPointer;
myIntegerPointerPointer = &myIntegerPointer1;

printf("Memory address of my integer:%p\n", &myInteger);
printf("%p\n",&myIntegerPointer1);
printf("%p\n",&(**myIntegerPointerPointer));
printf("Pointer to Pointer:%d\n",**myIntegerPointerPointer);

// declare another pointer to the integer above
int *myIntegerPointer2 = &myInteger;

// declare a 3rd pointer. This time, however, make it equal to one of
// the above pointers instead of getting the address again.
int *myIntegerPointer3 = myIntegerPointer2;

// print the values (addresses pointed to) of the pointers
printf("%p\n", myIntegerPointer1);
printf("%p\n", myIntegerPointer2);
printf("%p\n", myIntegerPointer3);

// print the value of the number the pointers point to
printf("%d\n", *myIntegerPointer1);
printf("%d\n", *myIntegerPointer2);
printf("%d\n", *myIntegerPointer3);

// let's change the number...
myInteger = 5000;

// ...and print the values of the pointers again
printf("%d\n", *myIntegerPointer1);
printf("%d\n", *myIntegerPointer2);
printf("%d\n", *myIntegerPointer3);
printf("Pointer to Pointer:%d\n",**myIntegerPointerPointer);
}
