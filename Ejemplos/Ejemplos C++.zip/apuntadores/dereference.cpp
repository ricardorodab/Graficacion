#include <iostream>
using namespace std;

int main(){

	// Creamos una variable
	int value = 10;

	// Creamos un apuntador a la direccion de 'value'
	int* valuePtr = &value;

	// Imprimimos 
	cout << "value= " << value << endl;
	cout << "valuePtr = " << valuePtr << endl;
	cout << "*valuePtr = " << *valuePtr << endl;

	// Modificamos 'value' por medio del apuntador dereferenciandolo
	*valuePtr = 500;

	// Imprimimos los cambios
	cout << "value= " << value << endl;
	cout << "valuePtr = " << valuePtr << endl;
	cout << "*valuePtr = " << *valuePtr << endl;

	return 0;
}

