#include <iostream>
using namespace std;

	int main(){
	
	// Creacion de una variable.
	int value = 10;

	// Creacion de una referencia a 'value'.
	int& valueRef = value;

	// Imprimir el numero en 'value'.
	cout << "value = " << value << endl;

	// Tambien imprimir el valor value referenciado por 'valueRef'.
	// imprime lo mismo que en 'value'.
	cout << "valueRef = " << valueRef << endl;

	// Modifica la referencia. Modificar 'valueRef' modifica 'value'.
	valueRef = 500;
	cout << "value = " << value << endl;
	cout << "valueRef = " << valueRef << endl;
}

