#include <iostream>

using namespace std;
 

	float Square(float x){
		return x * x;
	}

        //Ejemplo de una funcion que toma como parametro otra funcion por medio de 
	//apuntadores de funciones	
	bool functionA( int param1, int param2, bool (*verificar)( int param) ) {
		if( ( (*verificar)( param1 ) ) && ( (*verificar)( param2 ) ) )
			return true;
	}

	bool functionB( int param ) {
		if ( param > 100 )
			return true;
		else
			return false;
	}
  
	int main(){
		
                //Obtenemos un apuntador a la funcion Square. 
		//Nota el operador de direccion (&) no es necesario para apuntadores de funciones
		float (*squarePtr)(float x) = Square;
		// Llamamos a square por medio del apuntador
		cout << "squarePtr(2.0f) = " << squarePtr(2.0f) << endl;

		int x = 13, y = 226;
   		int z = 123, w = 234; 
		if ( functionA( x, y, functionB ) )
			cout << "\nEl resultado es verdadero\n";
		else
			cout << "\nEl resultado es falso\n";

		if ( functionA( z, w, functionB ) )
			cout << "\nEl resultado es verdadero\n";
		else
			cout << "\nEl resultado es falso\n";
		return 0;
	}
 


