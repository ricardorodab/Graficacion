#include <iostream>

using namespace std;

int main(){

	short arrayName[8] = {1, 2, 3, 4, 5, 6, 7, 8};

	//Usamos arrayName para obtener un apuntador al primer elemento
	short * firstPtr = arrayName;
	cout << "arrayName[0] = " << arrayName[0] << endl;
	cout << "*firstPtr dir= " << firstPtr << endl;
	cout << "*firstPtr val= " << *firstPtr << endl;

	//nos movemos en el arreglo usando la suma
	cout << "Style 1: Addition operator." << endl;
	for(int i = 0; i < 8; ++i)
	{
		cout << *(firstPtr + i) << " ";
	}
	cout << endl;

	//Nos movemos en el arreglo usando el operador incremento
	cout << "Style 2: Increment operator." << endl;
	for(int i = 0; i < 8; ++i)
	{
		cout << *firstPtr << " ";
		++firstPtr; // Movemos el apuntasor al siguiente elemento
	}
	cout << endl;
	return 0;
}

