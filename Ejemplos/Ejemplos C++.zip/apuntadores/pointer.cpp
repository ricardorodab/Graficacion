#include <iostream>
using namespace std;

int main(){


        //Variables
	bool boolVar = true;
	int intVar= 50;
	float floatVar = 3.14f;

	//Inicializamos los apuntadores a las direccion de 
	//las correspondientes variables
	bool* boolPtr = &boolVar;
	int* intPtr = &intVar;
	float* floatPtr = &floatVar;

	// Imprimimos las variables
	cout << "boolVar = " << boolVar << endl;
	cout << "intVar= " << intVar << endl; 
	cout << "floatVar = " << floatVar << endl;
	cout << endl;

        //Imprimimos las direcciones que estan almacenadas en los apuntadores
	cout << "boolPtr = Address of boolVar = " << boolPtr << endl;
	cout << "intPtr = Address of intVar= " << intPtr << endl;
	cout << "floatPtr = Address of floatVar = " << floatPtr << endl;
	return 0;
}

