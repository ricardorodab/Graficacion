#include <iostream>
#include <string>
 
using namespace std;

//Ejemplo de apuntadores nulos

enum Type
{
    INT,
    FLOAT
};
 
void Print(void *pValue, Type eType)
{
    switch (eType)
    {
        case INT:
            //Hacemos un cast al apuntador vacio
            //cout << *static_cast<int*>(pValue) << endl;
	    cout << *((int *)pValue) << endl;	
            break;
        case FLOAT:
            //Hacemos un cast al apuntador vacio
            //cout << *static_cast<float*>(pValue) << endl;
	    cout << *((float *)pValue) << endl;
            break;
    }
}
 
int main()
{
    int nValue = 5;
    float fValue = 7.5;
 
    Print(&nValue, INT);
    Print(&fValue, FLOAT);

    char cadena[10] = "Hola"; 
   
    char *c; 
    int *n; 
    void *v;
    float *f = &fValue; 
    c = cadena; // c apunta a cadena 
    n = (int *)cadena; // n también apunta a cadena 
    v = (void *)cadena; // v también 
    
    cout << "carácter: " << *c << endl; 
    cout << "entero:   " << *n << endl; 
    cout << "float:    " << *((float*)v) << endl; 

}
