#include <iostream>
#include <vector>

using namespace std;

int main(){

	vector<float> floatVec;
	floatVec.resize(12);
	cout << "My size = " << floatVec.size() << endl;
	for(int i = 0; i < 12; ++i)
		floatVec[i] = i;
	for(int i = 0; i < 12; ++i)
		cout << "floatVec[" << i << "] = " << floatVec[i] << endl;

}

